#!/usr/bin/env bash

sudo make install
ruby-install ruby
ruby-install jruby
ruby-install rubinius
